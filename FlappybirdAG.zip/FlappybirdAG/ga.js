function nextGeneration() {
    calculateFitness();

    console.log(birds);
    
    for (let i=0; i<TOTAL; i++){
        birds[i] = pickOne();
        // birds[i] = new Bird();
    }
    savedBirds = [];
}


// function pickOne() {
//     var index = 0;
//     var r = random(1);
//     console.log(birds);

//     while(r>0){
//         r = r - birds[index].fitness;
//         index++;   
//     }
//     index--;

//     let bird = birds[index];
//     let child = new Bird(bird.brain);
//     child.mutate();
//     return child;
// }

function pickOne(){
    let bird = random(savedBirds);
    let child = new Bird(bird.brain);
    //If you wanna do crossover, do it here
    // child.mutate();
    // child.brain.mutate();
    return child;
}

function calculateFitness(){
    let sum = 0;
    for (let bird of birds){
        sum += bird.score;
    }

    for (let bird of birds){
        bird.fitness = bird.score/sum; //Normalize between 0 and 1
    }
}