function Bird(brain) {
    //Contructor
    this.y = height/2;
    this.x = 64;
  
    this.gravity = 0.6;
    this.lift = -3;
    this.velocity = 0;

    this.score = 0;
    this.fitness = 0;
    //If we pass a brain as an parameter, we want to make a copy
    //Otherwise just create new bird
    if (brain) {
        this.brain = brain.copy();
    } else {
        this.brain = new NeuralNetwork(4, 4, 1);
    }

    //Methods  
    this.show = function() {
        stroke(255);
        fill(255, 100);
        ellipse(this.x, this.y, 32, 32);
    }
  
    this.up = function() {
      this.velocity += this.lift;
    }

    //A mutate function that mutates the birds brain
    this.mutate = function() {
        console.log('foi');
        this.brain.mutate(0.1); //PROBLEM IS HERE!!! 17:31 second video
        console.log('jkj');
    }

    this.think = function(pipes) {
        //Achar o tubo mais proximo
        let closest = null;
        let closestDistance = Infinity;
        for (let i=0; i<pipes.length; i++){
            let d = pipes[i].x - this.x;
            console.log('aqui');
            console.log(d);
            if (d < closestDistance){
                //Atualizar o mais proximo
                closest = pipes[i];
                closestDistance = d;
            }

        }
        
        let inputs = [];
        inputs[0] = this.y /height;
        inputs[1] = closest.top/height;
        inputs[2] = closest.bottom/height;
        inputs[3] = closest.x;

        let output = this.brain.predict(inputs);
        if (output[0] > 0.5){
            this.up();
        }
    }
  
    this.update = function() {
        this.score++;
        

        this.velocity += this.gravity;
        this.velocity *= 0.95; //A little deceleration, "air resistance"
        this.y += this.velocity;

        if (this.y > height) {
        this.y = height;
        this.velocity = 0;
        }

        if (this.y < 0) {
        this.y = 0;
        this.velocity = 0;
        }

    }
  
  }