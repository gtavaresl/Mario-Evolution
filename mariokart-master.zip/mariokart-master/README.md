All credits go to Jacob Seidelin, who created this game in 2008(!)

http://blog.nihilogic.dk/2008/05/javascript-super-mario-kart.html

